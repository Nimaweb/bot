<?php
// با دقت ادیت کن
$admins = [        //آیدی عددی ادمین ها
  918222513,
  918222513,
];
$web_url = "https://#/*";  //ادرس سورس   به جای # دامنه خود را وارد کنید و به جای * اسم پوشه سورس
$helper_id = ''; // آیدی ربات بدون @ وارد شود
$support_id= ''; // ایدی پشتیبان   (پیامرسان خود با @)
// ---
$plugins = [        //دست نزنید
"tools",
"sudo",
"delete",
"send",
"help",
];
$cplug = count($plugins) - 1;
for($n=0; $n<=$cplug; $n++) {
  $pluginlist = "cli/".$plugins[$n].".php";
  include($pluginlist);
}
@$data=json_decode(file_get_contents('data.json'),true);
$power = $data['bot'];
unlink("MadelineProto.log");