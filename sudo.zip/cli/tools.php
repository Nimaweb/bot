<?php
//ربات محافظ گروه cli
if($data['bot'] == "on"){
@$database = json_decode(file_get_contents("data/$chatID.json"),true);
$expire = $database['expire'];
$expire_time = $database['expire_time'];
$lang = $database['lang'];
$link = $database['link'];
$owner = $database['owner'];
$welcome = $database['welcome'];
$lock_all = $database['lock']['all'];
$lock_link = $database['lock']['link'];
$lock_text = $database['lock']['text'];
$lock_username = $database['lock']['username'];
$lock_english = $database['lock']['english'];
$lock_photo = $database['lock']['photo'];
$lock_document = $database['lock']['document'];
$lock_forward = $database['lock']['forward'];
$lock_voice = $database['lock']['voice'];
$lock_sticker = $database['lock']['sticker'];
$lock_location = $database['lock']['location'];
$lock_music = $database['lock']['music'];
$lock_tg = $database['lock']['tg'];
$lock_bot = $database['lock']['bot'];
$lock_tabchi = $database['lock']['tabchi'];
$lock_mention = $database['lock']['mention'];
$lock_inline = $database['lock']['inline'];
$lock_via = $database['lock']['via'];
$lock_contact = $database['lock']['contact'];
$lock_flood = $database['lock']['flood'];
$time_flood = $database['flood'];
$strict_mode = $database['strict_mode'];
$warn = $database['warn'];
@$database_warn = json_decode(file_get_contents("warn/$chatID.json"),true);
$warn_count = $database_warn["$userID"];
@$database_mute = json_decode(file_get_contents("mute/$chatID.json"),true);
$mute_time = $database_mute["$userID"]["time"];
//-------- Bot --------
$mee = $MadelineProto->get_full_info($userID);
$me = $mee['User'];
$first_name = $me['first_name'];
if($expire == "on"){
$date4 = date('Y-m-d', time());
if($date4 > $expire_time and $expire_time !== null){
unlink("data/$chatID.json");
unlink("admins/$chatID.txt");
unlink("mute/$chatID.txt");
unlink("filter/$chatID.txt");
unlink("warn/$chatID.json");
unlink("tabchi/$chatID.json");
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "شارژ گروه تمام شد و این گروه از لیست مدیریتی ربات حذف شد📛
درصورت نیاز به شارژ مجدد با مدیریت در ارتباط باشید :
@nulltheme_org 
$support_id️️",'reply_to_msg_id' => $msg_id,]);
$MadelineProto->channels->leaveChannel(['channel' => $chatID, ]);
}
//-------- Welcome-Bot --------
if($welcome !== "disable"){
if($update['update']['message']['action']['_'] == "messageActionChatJoinedByLink" or $update['update']['message']['action']['_'] == "messageActionChatAddUser"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "$welcome",'reply_to_msg_id' => $msg_id,]);	
}
}
$type = $MadelineProto->get_info($chatID);
$typ = $type['type'];
if($typ == "supergroup"){
//-------- Ping-Bot --------
if($msg == 'ping' || $msg == 'Ping' || $msg == 'ربات' || $msg == 'آنلاینی' || $msg == 'انلاینی'){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => '<a href="mention:'.$userID.'">رضا مگ میزاره اف شم</a>','parse_mode' => 'html']);

}
//-------- mantion-Bot --------
if($msg == 'منشن' || $msg == 'منشن من' || $msg == 'mantion'){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => '<a href="mention:'.$userID.'"> اینم منشن اکانت شما  :( '.$first_name.'</a>','parse_mode' => 'html']);

}
//speed 
if($msg == 'speed' || $msg == 'سرعت'){
$gettime = json_decode(file_get_contents("http://api.bot-dev.org/time/"),true);
$time = $gettime["ENtime"];
$date_fa = $gettime["FAdate"];
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => 'الان سرعت رباتو میبینی']);
sleep(2);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【2】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【3】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【4】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【5】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【6】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【7】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【8】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【9】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【0】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【1】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【2】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【3】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【4】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【5】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【6】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【7】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【8】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【1】【9】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【2】【0】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【2】【1】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【2】【2】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【2】【3】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【2】【4】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => '【2】【5】']);
sleep(0.05);
for ($i=5; $i <= 50; $i++){
$ed =  $MadelineProto->messages->editMessage(['peer' => $chatID, 'id' => $msg_id + 1, 'message' => 'اینم سرعت ربات کلینر 😍

فرد تست کننده :
'.$first_name.'
~~~~~~~~~~
زمان  :
'.$time.'
~~~~~~~~~
…………………………
'.$date_fa.'
^^^^^^^^^^^^^']);
sleep(0.05);
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
//-------- Sudo-Bot --------
if($msg == 'sudo' || $msg == 'سازنده' || $msg == 'مالک ربات' || $msg == 'مالک' || $msg == 'صاحب'){
 $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => 'سازنده و مالک اصلی ربات
@nulltheme_org 
میباشد✅
دستور داده شده توسط  '.$first_name.'','parse_mode' => 'html']);

}

if($msg == 'stats'){
        $res = ['bot' => 0, 'user' => 0, 'chat' => 0, 'channel' => 0, 'supergroup' => 0];
        foreach ($MadelineProto->get_dialogs() as $dialog) {
            $res[$MadelineProto->get_info($dialog)['type']]++;
        }
        $g = json_encode($res);
        $gf = json_decode($g);
        $users = $gf->user;
        $groups = $gf->chat;
        $supergroups = $gf->supergroup;
        $channels = $gf->channel;
        $bots = $gf->bot;
        $MadelineProto->messages->sendMessage([
            'peer' => $chatID,
            'message'=> "تعداد پیوی ها: $users\nتعداد گروه ها: $groups\nتعداد سوپر گروه ها: $supergroups\nتعداد کانال ها: $channels\nتعداد ربات ها: $bots\n\n🆔👉 @nulltheme_org "
        ]);
    }
//delete
$sudo="694053280";  //آیدی عددی سودو
if($userID==$sudo and preg_match("/^[#\!\/](del) (.*)$/", $msg)){
preg_match("/^[#\!\/](del) (.*)$/", $msg, $text1);
$a=$text1[2];
for($c=0; $c<$a; $c++){
$mga=$msg_id-$c;
try{
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$mga], ]);
}catch(\danog\MadelineProto\RPCErrorException $e){
 }catch(\danog\MadelineProto\Exception $e){
    }catch(\danog\MadelineProto\TL\Conversion\Exception $e){
 }
}
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>"● پاکسازی به طور کامل انجام شد تعداد : $a پیام حذف شدند"]); 
}
//-------- Suport-Bot --------
if($msg == 'پشتیبانی' || $msg == '
suport'){
 $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => 'جهت ارتباط با پشتیبانی :
@nulltheme_org 
✅✅✅✅✅✅
ریپورتی ها : 
@nulltheme_org  
✅✅✅✅✅✅✅✅✅✅
دستور داده شده توسط * '.$first_name.' *','parse_mode' => 'html']);

}
//-------- Translate-Bot --------
if(strpos($msg,"ترجمه ") !== false){
$word = trim(str_replace("ترجمه ","",$msg));
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_to_msg_id = $update['update']['message']['reply_to_msg_id'];
$messag1 = $gmsg['messages'][0]['message'];
$messag = str_replace(" ","+",$messag1);
if($word == "فارسی"){
$url="https://translate.yandex.net/api/v1.5/tr.json/translate?key=trnsl.1.1.20160119T111342Z.fd6bf13b3590838f.6ce9d8cca4672f0ed24f649c1b502789c9f4687a&format=plain&lang=fa&text=$messag";
$jsurl=json_decode(file_get_contents($url),true);
$text9=$jsurl['text'][0];
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ترجمه این متن به زبان فارسی :
<code>$text9</code>",'reply_to_msg_id' => $reply_to_msg_id,'parse_mode' => 'html']);
}
if($word == "انگلیسی"){
$url="https://translate.yandex.net/api/v1.5/tr.json/translate?key=trnsl.1.1.20160119T111342Z.fd6bf13b3590838f.6ce9d8cca4672f0ed24f649c1b502789c9f4687a&format=plain&lang=en&text=$messag";
$jsurl=json_decode(file_get_contents($url),true);
$text9=$jsurl['text'][0];
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ترجمه این متن به زبان انگلیسی :
<code>$text9</code>",'reply_to_msg_id' => $reply_to_msg_id,'parse_mode' => 'html']);
}
if($word == "عربی"){
$url="https://translate.yandex.net/api/v1.5/tr.json/translate?key=trnsl.1.1.20160119T111342Z.fd6bf13b3590838f.6ce9d8cca4672f0ed24f649c1b502789c9f4687a&format=plain&lang=ar&text=$messag";
$jsurl=json_decode(file_get_contents($url),true);
$text9=$jsurl['text'][0];
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ترجمه این متن به زبان عربی :
<code>$text9</code>",'reply_to_msg_id' => $reply_to_msg_id,'parse_mode' => 'html']);
}
}
}
if(strpos($msg,"translate ") !== false){
$word = trim(str_replace("translate ","",$msg));
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_to_msg_id = $update['update']['message']['reply_to_msg_id'];
$messag1 = $gmsg['messages'][0]['message'];
$messag = str_replace(" ","+",$messag1);
if($word == "fa"){
$url="https://translate.yandex.net/api/v1.5/tr.json/translate?key=trnsl.1.1.20160119T111342Z.fd6bf13b3590838f.6ce9d8cca4672f0ed24f649c1b502789c9f4687a&format=plain&lang=fa&text=$messag";
$jsurl=json_decode(file_get_contents($url),true);
$text9=$jsurl['text'][0];
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ترجمه این متن به زبان فارسی :
<code>$text9</code>",'reply_to_msg_id' => $reply_to_msg_id,'parse_mode' => 'html']);
}
if($word == "en"){
$url="https://translate.yandex.net/api/v1.5/tr.json/translate?key=trnsl.1.1.20160119T111342Z.fd6bf13b3590838f.6ce9d8cca4672f0ed24f649c1b502789c9f4687a&format=plain&lang=en&text=$messag";
$jsurl=json_decode(file_get_contents($url),true);
$text9=$jsurl['text'][0];
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ترجمه این متن به زبان انگلیسی :
<code>$text9</code>",'reply_to_msg_id' => $reply_to_msg_id,'parse_mode' => 'html']);
}
if($word == "ar"){
$url="https://translate.yandex.net/api/v1.5/tr.json/translate?key=trnsl.1.1.20160119T111342Z.fd6bf13b3590838f.6ce9d8cca4672f0ed24f649c1b502789c9f4687a&format=plain&lang=ar&text=$messag";
$jsurl=json_decode(file_get_contents($url),true);
$text9=$jsurl['text'][0];
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ترجمه این متن به زبان عربی :
<code>$text9</code>",'reply_to_msg_id' => $reply_to_msg_id,'parse_mode' => 'html']);
}
}
}
//-------- Time-Bot --------
if($msg == 'time' || $msg == '/time' || $msg == '!time' || $msg == 'ساعت' || $msg == 'زمان'){
$gettime = json_decode(file_get_contents("http://api.bot-dev.org/time/"),true);
$time = $gettime["ENtime"];
$date_fa = $gettime["FAdate"];
$date_en = $gettime["ENdate"];
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => '<a href="mention:'.$userID.'">Time :</a>
🕐Time : <b>'.$time.'</b>
▫️Date-En : '.$date_en.'
▪️Date-Fa : '.$date_fa.'','parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => '<a href="mention:'.$userID.'">زمان :</a>
🕐ساعت : <b>'.$time.'</b>
▫️تاریخ میلادی : '.$date_en.'
▪️تاریخ شمسی :'.$date_fa.'','parse_mode' => 'html']);	
}
}
//-------- Link-Bot --------
if($msg =="لینک" || $msg =="لینک گروه" || $msg =="/link" || $msg =="!link" || $msg =="link"){
if($link !== null){
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔹Group Link :
'.$link.'
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔹لینک گروه :
'.$link.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لینک گروه ثبت نشده است📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Id-Bot --------
if($msg =="آیدی" || $msg=="ایدی" || $msg=="/id" || $msg=="id" || $msg=="!id" || $msg=="me" || $msg=="/me" || $msg=="!me"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
$photos_Photos = $MadelineProto->photos->getUserPhotos(['user_id' => $reply_from_id, 'offset' => 0, 'max_id' => 0, 'limit' => 1, ]);
$photo_id=$photos_Photos['photos']['0']['id'];
$photo_hash=$photos_Photos['photos']['0']['access_hash'];
$mee = $MadelineProto->get_full_info($reply_from_id);
if($photo_id == null){
$me = $mee['User'];
$me_id = $me['id'];
$me_status = $me['status']['_'];
$me_bio = $mee['full']['about'];
$me_name = $me['first_name'];
$me_uname = $me['username']; 
@$database_warn = json_decode(file_get_contents("warn/$chatID.json"),true);
$warn_count = $database_warn["$reply_from_id"];
if($warn_count == null){
$warn_count = 0;
}
$mes_fa = "🔺شناسه : **$me_id**
🔻نام : $me_name
🔸یوزرنیم : @$me_uname
📍تعداد اخطار های شما : $warn_count
▫️تعداد پیام های گروه : $msg_id";
$mes_en = "🔺ID : **$me_id**
🔻Name : $me_name
🔸Username : @$me_uname
📍Warns : $warn_count
▫Group Msgs Count : $msg_id";
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => $mes_en,'reply_to_msg_id' => $msg_id,]);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => $mes_fa,'reply_to_msg_id' => $msg_id,]);	
}
}
if($photo_id !== null){
$me = $mee['User'];
$me_id = $me['id'];
$me_status = $me['status']['_'];
$me_bio = $mee['full']['about'];
$me_name = $me['first_name'];
$me_uname = $me['username']; 
@$database_warn = json_decode(file_get_contents("warn/$chatID.json"),true);
$warn_count = $database_warn["$reply_from_id"];
if($warn_count == null){
$warn_count = 0;
}
$mes_fa = "🔺شناسه : **$me_id**
🔻نام : $me_name
🔸یوزرنیم : @$me_uname
📍تعداد اخطار های شما : $warn_count
▫️تعداد پیام های گروه : $msg_id";
$mes_en = "🔺ID : **$me_id**
🔻Name : $me_name
🔸Username : @$me_uname
📍Warns : $warn_count
▫Group Msgs Count : $msg_id";
if($lang == "en"){
$inputPhoto = ['_' => 'inputPhoto', 'id' => $photo_id, 'access_hash' => $photo_hash];
 $inputMediaPhoto = ['_' => 'inputMediaPhoto', 'id' => $inputPhoto, ];
$MadelineProto->messages->sendMedia([ 'peer' => $chatID, 'media' => $inputMediaPhoto,'message' => "$mes_en"]);
}else{
$inputPhoto = ['_' => 'inputPhoto', 'id' => $photo_id, 'access_hash' => $photo_hash];
 $inputMediaPhoto = ['_' => 'inputMediaPhoto', 'id' => $inputPhoto, ];
$MadelineProto->messages->sendMedia([ 'peer' => $chatID, 'media' => $inputMediaPhoto,'message' => "$mes_fa"]);
}
}
}
if(isset($update['update']['message']['reply_to_msg_id']) == null){
$photos_Photos = $MadelineProto->photos->getUserPhotos(['user_id' => $userID, 'offset' => 0, 'max_id' => 0, 'limit' => 1, ]);
$photo_id=$photos_Photos['photos']['0']['id'];
$photo_hash=$photos_Photos['photos']['0']['access_hash'];
$mee = $MadelineProto->get_full_info($userID);
if($photo_id == null){
$me = $mee['User'];
$me_id = $me['id'];
$me_status = $me['status']['_'];
$me_bio = $mee['full']['about'];
$me_name = $me['first_name'];
$me_uname = $me['username']; 
if($warn_count == null){
$warn_count = 0;
}
$mes_fa = "🔺شناسه : **$me_id**
🔻نام : $me_name
🔸یوزرنیم : @$me_uname
📍تعداد اخطار های شما : $warn_count
▫️تعداد پیام های گروه : $msg_id";
$mes_en = "🔺ID : **$me_id**
🔻Name : $me_name
🔸Username : @$me_uname
📍Warns : $warn_count
▫Group Msgs Count : $msg_id";
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => $mes_en,'reply_to_msg_id' => $msg_id,]);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => $mes_fa,'reply_to_msg_id' => $msg_id,]);	
}
}else{
$me = $mee['User'];
$me_id = $me['id'];
$me_status = $me['status']['_'];
$me_bio = $mee['full']['about'];
$me_name = $me['first_name'];
$me_uname = $me['username']; 
if($warn_count == null){
$warn_count = 0;
}
$mes_fa = "🔺شناسه : **$me_id**
🔻نام : $me_name
🔸یوزرنیم : @$me_uname
📍تعداد اخطار های شما : $warn_count
▫️تعداد پیام های گروه : $msg_id";
$mes_en = "🔺ID : **$me_id**
🔻Name : $me_name
🔸Username : @$me_uname
📍Warns : $warn_count
▫Group Msgs Count : $msg_id";
if($lang == "en"){
$inputPhoto = ['_' => 'inputPhoto', 'id' => $photo_id, 'access_hash' => $photo_hash];
 $inputMediaPhoto = ['_' => 'inputMediaPhoto', 'id' => $inputPhoto, ];
$MadelineProto->messages->sendMedia([ 'peer' => $chatID, 'media' => $inputMediaPhoto,'message' => "$mes_en"]);
}else{
$inputPhoto = ['_' => 'inputPhoto', 'id' => $photo_id, 'access_hash' => $photo_hash];
 $inputMediaPhoto = ['_' => 'inputMediaPhoto', 'id' => $inputPhoto, ];
$MadelineProto->messages->sendMedia([ 'peer' => $chatID, 'media' => $inputMediaPhoto,'message' => "$mes_fa"]);
}
}
}
}
if($msg == "info" || $msg == "gpinfo" || $msg == "/info" || $msg == "!info" || $msg == "اطلاعات"){
@$photos_Photos = $MadelineProto->get_full_info($chatID);
$pic_gp = $photos_Photos['Chat']['photo']['_'];
if($pic_gp !== "chatPhotoEmpty"){
$photos_Photos = $MadelineProto->get_full_info($chatID);
$photo_id=$photos_Photos['full']['chat_photo']['id'];
$photo_hash=$photos_Photos['full']['chat_photo']['access_hash'];
$bot_api_id = $photos_Photos['bot_api_id'];
$about = $photos_Photos['full']['about'];
$kicked_count = $photos_Photos['full']['kicked_count'];
$participants_count = $photos_Photos['full']['participants_count'];
$admins_count = $photos_Photos['full']['admins_count'];
$banned_count = $photos_Photos['full']['banned_count'];
$title = $photos_Photos['Chat']['title'];
$mes_en = "🔺ID : $bot_api_id
🔻Name : $title
🔸About : 
$about
▫️Group Members Count : $participants_count";
$inputPhoto = ['_' => 'inputPhoto', 'id' => $photo_id, 'access_hash' => $photo_hash];
 $inputMediaPhoto = ['_' => 'inputMediaPhoto', 'id' => $inputPhoto, ];
$MadelineProto->messages->sendMedia([ 'peer' => $chatID, 'media' => $inputMediaPhoto,'message' => "$mes_en"]);
}
if($pic_gp == "chatPhotoEmpty"){
$photos_Photos = $MadelineProto->get_full_info($chatID);
$photo_id=$photos_Photos['full']['chat_photo']['id'];
$photo_hash=$photos_Photos['full']['chat_photo']['access_hash'];
$bot_api_id = $photos_Photos['bot_api_id'];
$about = $photos_Photos['full']['about'];
$kicked_count = $photos_Photos['full']['kicked_count'];
$participants_count = $photos_Photos['full']['participants_count'];
$admins_count = $photos_Photos['full']['admins_count'];
$banned_count = $photos_Photos['full']['banned_count'];
$title = $photos_Photos['Chat']['title'];
$mes_en = "🔺ID : $bot_api_id
🔻Name : $title
🔸About : 
$about
▫️Group Members Count : $participants_count
▫️Admin Count : $admins_count
▫️Kicked Count : $kicked_count
▫️Banned Count : $banned_count";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => $mes_en,'reply_to_msg_id' => $msg_id,]);	
}
}
//------- بخش مربوط به گروه ها -------
@$admin_list = file_get_contents("admins/$chatID.txt");
$exp=explode("\n",$admin_list);
if(in_array($userID,$exp)){
//-------- Panel-Bot --------
 if($msg =="پنل" || $msg=="panel" || $msg=="/panel" || $msg=="Panel" || $msg=="مدیریت" || $msg=="منو" || $msg=="فهرست"){
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => $helper_id, 'peer' => $chatID, 'query' => "panel_$chatID", 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
//-------- Settings-Bot -------
if($msg =="تنظیمات" || $msg == "وضعیت" || $msg =="/settings" || $msg =="!settings" || $msg =="settings"){
date_default_timezone_set('Asia/Tehran');
$time2 = date('Y-m-d');
$ndate = $database['expire_time'];
$diff = strtotime($ndate) - strtotime($time2);
if($diff < 60){
        $endtime = $diff;
    }
    elseif($diff < 3600){
        $endtime = round($diff / 60,0,1);
    }
    elseif($diff >= 3660 && $diff < 86400){
        $endtime = round($diff / 3600,0,1);
    }
    elseif($diff > 86400){
        $endtime = round($diff / 86400,0,1);
    }
$text_fa = "📍تنظیمات ربات ضد اسپم در گروه شما :
🔸قفل لینک : $lock_link
🔹قفل یوزرنیم : $lock_username
🔸قفل فروارد : $lock_forward
🔹قفل عکس : $lock_photo
🔸قفل ویس : $lock_voice
🔹قفل موزیک : $lock_music
🔸قفل استیکر : $lock_sticker
🔹قفل لوکیشن : $lock_location
🔸قفل خدمات تلگرام : $lock_tg
🔹قفل ورود ربات  : $lock_bot
🔸قفل رسانه : $lock_document
🔹قفل دکمه شیشه ای : $lock_inline
🔸قفل فراخوانی : $lock_via
🔹قفل متن : $lock_text
🔸قفل منشن : $lock_mention
🔹قفل مخاطب : $lock_contact
🔸قفل اسپم : $lock_flood | $time_flood
🔹قفل انگلیسی : $lock_english
🔸قفل همه : $lock_all
🔹ورود تبچی : $lock_tabchi
🔸حالت سخت : $strict_mode
♻️♻️♻️♻️♻️♻️♻️♻️
▫️خوشامد گویی به اعضای جدید :
$welcome
⏱گروه شما $endtime روز دیگر شارژ دارد.
📍تعداد حداکثر اخطار : $warn
▪️زبان ربات در گروه شما نیز $lang میباشد❕";
$text_en = "📍Anti-Spam Robot Settings in Your Group :
🔸Lock Link : $lock_link
🔹Lock Username : $lock_username
🔸Lock Forward : $lock_forward
🔹Lock Photo : $lock_photo
🔸Lock Voice : $lock_voice
🔹Lock Music : $lock_music
🔸Lock Sticker : $lock_sticker
🔹Lock Locatio‌n : $lock_location
🔸Lock TgService : $lock_tg
🔹Lock Robot : $lock_bot
🔸Lock Docume‌nt : $lock_document
🔹Lock Inline : $lock_inline
🔸Lock Via : $lock_via
🔹Lock Text : $lock_text
🔸Lock Me‌ntio‌n : $lock_mention
🔹Lock Co‌ntact : $lock_contact
🔸Lock Flood : $lock_flood | $time_flood
🔹Lock English : $lock_english
🔸Lock All : $lock_all
🔹Join Tabchi : $lock_tabchi
🔸Strict Mode : $strict_mode
♻️♻️♻️♻️♻️♻️♻️♻️
▫️Welcom Msg Is :
$welcome
⏱Your group has a charge of $endtime days
📍Last Warn Count : $warn
▪️ Robots are also in your group $lang";
if($lang == "en"){
$text_1 = str_replace("on","🔐",$text_en);
$text_2 = str_replace("off","🔓",$text_1);
$text_3 = str_replace("fa","Persion",$text_2);
$text_4 = str_replace("disable","None❕",$text_3);
$text_5 = str_replace("en","English",$text_4);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => $text_5,'reply_to_msg_id' => $msg_id,]);
}else{
$text_1 = str_replace("on","🔐",$text_fa);
$text_2 = str_replace("off","🔓",$text_1);
$text_3 = str_replace("fa","فارسی",$text_2);
$text_4 = str_replace("disable","غیرفعال❕",$text_3);
$text_5 = str_replace("en","انگلیسی",$text_4);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => $text_5,'reply_to_msg_id' => $msg_id,]);	
}
}
//-------- Expire-Bot --------
if($msg =="اعتبار" || $msg == "expire" || $msg =="میزان شارژ" || $msg =="شارژ" || $msg =="Expire"){
date_default_timezone_set('Asia/Tehran');
$time2 = date('Y-m-d');
$ndate = $database['expire_time'];
$diff = strtotime($ndate) - strtotime($time2);
if($diff < 60){
        $endtime = $diff;
    }
    elseif($diff < 3600){
        $endtime = round($diff / 60,0,1);
    }
    elseif($diff >= 3660 && $diff < 86400){
        $endtime = round($diff / 3600,0,1);
    }
    elseif($diff > 86400){
        $endtime = round($diff / 86400,0,1);
    }
$text_fa = "⏱گروه شما $endtime روز دیگر شارژ دارد.
";
$text_en = "⏱Your group has a charge of $endtime days";
if($lang == "en"){
$text_1 = str_replace("on","🔐",$text_en);
$text_2 = str_replace("off","🔓",$text_1);
$text_3 = str_replace("fa","Persion",$text_2);
$text_4 = str_replace("disable","None❕",$text_3);
$text_5 = str_replace("en","English",$text_4);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => $text_5,'reply_to_msg_id' => $msg_id,]);
}else{
$text_1 = str_replace("on","🔐",$text_fa);
$text_2 = str_replace("off","🔓",$text_1);
$text_3 = str_replace("fa","فارسی",$text_2);
$text_4 = str_replace("disable","غیرفعال❕",$text_3);
$text_5 = str_replace("en","انگلیسی",$text_4);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => $text_5,'reply_to_msg_id' => $msg_id,]); 
}
}
//--------- Nerkh_Bot --------
if($msg == 'نرخ' || $msg == 'پرداخت' || $msg == 'nerkh'){
 $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => '<code>ربات TELE SPEED به درخواست سازنده ربات ♡ @nulltheme_org   ♡رایگان شد.</code>','parse_mode' => 'html']);

}
//-------- Clean-Deleted-Bot --------
if($msg =="/clean deleted" || $msg=="clean deleted" || $msg=="!clean deleted" || $msg=="پاکسازی دلت اکانت ها" || $msg=="حذف دلت اکانت ها"){
$channelParticipantsRecent = ['_' => 'channelParticipantsRecent'];
$channels_ChannelParticipants = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' => $channelParticipantsRecent, 'offset' => 0, 'limit' => 200, 'hash' => 0, ]);
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$kl = $channels_ChannelParticipants['users'];
$list = "";
foreach($kl as $key=>$val){
$fon = $kl[$key]['deleted'];
$fonid = $kl[$key]['id'];
if($fon == true){
$list .= ''.$kl[$key]['id']."\n";
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $fonid,
'banned_rights' => $channelBannedRights]);
}
}
$alaki = explode("\n",$list);
$allcount = count($alaki)-1;
$MadelineProto->messages->sendMessage(['peer'=>$chatID,'reply_to_msg_id'=>$msg_id,'message'=>"تعداد $allcount کاربر دیلیت اکانت از گروه شما پاک شد📍"]);
}
//-------- Clean-Bots-Bot --------
if($msg =="/clean bots" || $msg=="clean bots" || $msg=="!clean bots" || $msg=="پاکسازی ربات ها" || $msg=="حذف ربات ها"){
$channelParticipantsRecent = ['_' => 'channelParticipantsRecent'];
$channels_ChannelParticipants = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' => $channelParticipantsRecent, 'offset' => 0, 'limit' => 200, 'hash' => 0, ]);
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$kl = $channels_ChannelParticipants['users'];
$list = "";
foreach($kl as $key=>$val){
$fon = $kl[$key]['bot'];
$fonid = $kl[$key]['id'];
if($fon == true){
$list .= ''.$kl[$key]['id']."\n";
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $fonid,
'banned_rights' => $channelBannedRights]);
}
}
$alaki = explode("\n",$list);
$allcount = count($alaki)-1;
$MadelineProto->messages->sendMessage(['peer'=>$chatID,'reply_to_msg_id'=>$msg_id,'message'=>"تعداد $allcount ربات از گروه شما پاک شد📍"]);
}
//-------- Config-Bot --------
if($msg =="پیکربندی" || $msg =="config" || $msg =="/config" || $msg =="!config"){
if (!in_array($userID, $admins) and $userID == $owner){
$admins1 = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' =>['_' => 'channelParticipantsAdmins'], 'offset' => 0, 'limit' => 25, 'hash' => 0, ]);
$res = '';
foreach($admins1['participants'] as $admin){
$res .= ''.$admin['user_id']."\n";
file_put_contents("admins/$chatID.txt",$res);
}
$names_length=count($admins);  
for($x=0;$x<$names_length;$x++){
$rr = "$admins[$x]";
$myfile2 = fopen("admins/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$rr\n");
fclose($myfile2);
}
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'All Admins Has Been Promoted♻️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'همه ادمین های گروه با موفقیت مدیر ربات شدند♻️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- Auto-Manage-Bot --------
if($msg == "auto manage" or $msg == "/auto manage" or $msg == "!auto manage" or $msg == "تنظیمات خودکار" or $msg == "حالت خودکار"){
$database['warn'] = 3;
$database['flood'] = 3;
$database['lock']['all'] = "off";
$database['lock']['link'] = "on";
$database['lock']['text'] = "off";
$database['lock']['username'] = "on";
$database['lock']['english'] = "off";
$database['lock']['photo'] = "off";
$database['lock']['document'] = "off";
$database['lock']['voice'] = "off";
$database['lock']['sticker'] = "off";
$database['lock']['location'] = "on";
$database['lock']['forward'] = "on";
$database['lock']['music'] = "off";
$database['lock']['tg'] = "on";
$database['lock']['bot'] = "on";
$database['lock']['tabchi'] = "off";
$database['lock']['via'] = "on";
$database['lock']['inline'] = "on";
$database['lock']['contact'] = "on";
$database['lock']['mention'] = "on";
$database['lock']['flood'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Auto Manage Set , You Can See Your Group Settings with : settings✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'حالت قفل آتوماتیک فعال شد , شما میتوانید تنظیمات گروه خود را با دستور : تنظیمات مشاهده کنید✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- clean-msgs-pro-Bot --------
if($msg == "clean msgs" or $msg == "/clean msgs" or $msg == "!clean msgs" or $msg == "پاکسازی پیام ها" or $msg == "حذف پیام ها"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $update["update"]["message"]["reply_to_msg_id"];
$count = 10000;
$array = [];
$goal = $gmsg - 10000;
for($i=$gmsg;$i>=$goal;$i--){
$array[] = $i;
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => $array]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Last <b>'.$count.'</b> Messages Cleared✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<b>'.$count.'</b> پیام آخر گروه پاک شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- Rmsgs-Bot --------
if(preg_match("/[\/\!\#]del ([0-9]*)/", $msg)){
preg_match("/[\/\!\#]del ([0-9]*)/", $msg, $r);
$count = $r[1];
if($count < 5001){
$array = [];
$goal = $msg_id - $r[1];
for($i=$msg_id;$i>=$goal;$i--){
$array[] = $i;
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => $array]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Last <b>'.$count.'</b> Messages Cleared✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<b>'.$count.'</b> پیام آخر گروه پاک شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "مقدار وارد شده بیش از حد زیاد است❕
عددی زیر 5000 ارسال کنید👌🏻",'reply_to_msg_id' => $msg_id,]);
}
}
//-------- Flood-Time-Bot --------
if(preg_match("/[\/\!\#]setflood ([0-9]*)/", $msg)){
preg_match("/[\/\!\#]setflood ([0-9]*)/", $msg, $r);
$count = $r[1];
if($count < 50){
$database['flood'] = $count;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Flood Time is <b>'.$count.'</b> Now✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'زمان برسی پیام اسپم بروی <b>'.$count.'</b> تنظیم شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "مقدار وارد شده بیش از حد زیاد است❕
عددی زیر 50 ارسال کنید👌🏻",'reply_to_msg_id' => $msg_id,]);
}
}
if(strpos($msg,"تنظیم فلود ") !== false){
$count = trim(str_replace("تنظیم فلود ","",$msg));
if($count < 50){
$database['flood'] = $count;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Flood Time is <b>'.$count.'</b> Now✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'زمان برسی پیام اسپم بروی <b>'.$count.'</b> تنظیم شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "مقدار وارد شده بیش از حد زیاد است❕
عددی زیر 50 ارسال کنید👌🏻",'reply_to_msg_id' => $msg_id,]);
}
}
//-------- Warn-Count-Bot --------
if(preg_match("/[\/\!\#]setwarn ([0-9]*)/", $msg)){
preg_match("/[\/\!\#]setwarn ([0-9]*)/", $msg, $r);
$count = $r[1];
if($count < 50){
$database['warn'] = $count;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Warn Count Is <b>'.$count.'</b> Now✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'بیشترین تعداد اخطار بروی <b>'.$count.'</b> تنظیم شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "مقدار وارد شده بیش از حد زیاد است❕
عددی زیر 50 ارسال کنید👌🏻",'reply_to_msg_id' => $msg_id,]);
}
}
if(strpos($msg,"تنظیم اخطار ") !== false){
$count = trim(str_replace("تنظیم اخطار ","",$msg));
if($count < 50){
$database['warn'] = $count;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Warn Count Is <b>'.$count.'</b> Now✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'بیشترین تعداد اخطار بروی <b>'.$count.'</b> تنظیم شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "مقدار وارد شده بیش از حد زیاد است❕
عددی زیر 50 ارسال کنید👌🏻",'reply_to_msg_id' => $msg_id,]);
}
}
//-------- Warn-Bot --------
if(strpos($msg,"اخطار دادن ") !== false){
$text = trim(str_replace("اخطار دادن ","",$msg));
$mee = $MadelineProto->get_full_info($text);
$me = $mee['User'];
$me_id = $me['id'];
$first_name1 = $me['first_name'];
if(!in_array($me_id,$exp)){
if(!in_array($me_id,$admins)){
$warn_count = $database_warn["$me_id"];
settype($warn_count,"integer");
$newwarn = $warn_count + 1;
if($newwarn < $warn){
$database_warn["$me_id"] = $newwarn;
$outjson = json_encode($database_warn,true);
file_put_contents("warn/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User <a href="mention:'.$me_id.'">'.$first_name1.'</a> Get A Warn📛
⭕️your warns : '.$newwarn.' / '.$warn.'
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$me_id.'">'.$first_name1.'</a> یک اخطار دریافت کرد📛
⭕️تعداد اخطار های فرد : '.$newwarn.' / '.$warn.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
if($strict_mode == "disable"){
$database_mute["$me_id"]["time"] = "0";
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$me_id.'">'.$first_name1.'</a> یک اخطار دریافت کرد📛
⭕️تعداد اخطار های فرد : '.$newwarn.' / '.$warn.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$me_id.'">'.$first_name1.'</a> به لیست سکوت گروه اضافه شد📛
بدلیل دریافت اخطار 📍','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}else{
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $me_id,
'banned_rights' => $channelBannedRights]);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$me_id.'">'.$first_name1.'</a> از گروه اخراج شد📛
بدلیل دریافت اخطار 📍','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم به صاحب ربات در گروه اخطار بدهم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم به مدیر ربات در گروه اخطار بدهم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(preg_match("/^[\/\#\!]?(warn) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(warn) (.*)$/i", $msg, $text);
$mee = $MadelineProto->get_full_info($text[2]);
$me = $mee['User'];
$me_id = $me['id'];
$first_name1 = $me['first_name'];
if(!in_array($me_id,$exp)){
if(!in_array($me_id,$admins)){
$warn_count = $database_warn["$me_id"];
settype($warn_count,"integer");
$newwarn = $warn_count + 1;
if($newwarn < $warn){
$database_warn["$me_id"] = $newwarn;
$outjson = json_encode($database_warn,true);
file_put_contents("warn/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User <a href="mention:'.$me_id.'">'.$first_name1.'</a> Get A Warn📛
⭕️your warns : '.$newwarn.' / '.$warn.'
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$me_id.'">'.$first_name1.'</a> یک اخطار دریافت کرد📛
⭕️تعداد اخطار های فرد : '.$newwarn.' / '.$warn.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
if($strict_mode == "disable"){
$database_mute["$me_id"]["time"] = "0";
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$me_id.'">'.$first_name1.'</a> یک اخطار دریافت کرد📛
⭕️تعداد اخطار های فرد : '.$newwarn.' / '.$warn.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$me_id.'">'.$first_name1.'</a> به لیست سکوت گروه اضافه شد📛
بدلیل دریافت اخطار 📍','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}else{
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $me_id,
'banned_rights' => $channelBannedRights]);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$me_id.'">'.$first_name1.'</a> از گروه اخراج شد📛
بدلیل دریافت اخطار 📍','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم به صاحب ربات در گروه اخطار بدهم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم به مدیر ربات در گروه اخطار بدهم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if($msg =="اخطار" || $msg=="/warn" || $msg=="warn" || $msg=="!warn" || $msg == "اخطار دادن"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$repid = $gmsg['messages'][0]['from_id'];
if(!in_array($repid,$exp)){
if(!in_array($repid,$admins)){
$warn_count = $database_warn["$repid"];
settype($warn_count,"integer");
$newwarn = $warn_count + 1;
if($newwarn < $warn){
$database_warn["$repid"] = $newwarn;
$outjson = json_encode($database_warn,true);
file_put_contents("warn/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User <a href="mention:'.$repid.'">'.$repid.'</a> Get A Warn📛
⭕️your warns : '.$newwarn.' / '.$warn.'
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$repid.'">'.$repid.'</a> یک اخطار دریافت کرد📛
⭕️تعداد اخطار های فرد : '.$newwarn.' / '.$warn.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
if($strict_mode == "disable"){
$database_mute["$repid"]["time"] = "0";
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$repid.'">'.$repid.'</a> یک اخطار دریافت کرد📛
⭕️تعداد اخطار های فرد : '.$newwarn.' / '.$warn.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$repid.'">'.$repid.'</a> به لیست سکوت گروه اضافه شد📛
بدلیل دریافت اخطار 📍','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}else{
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $me_id,
'banned_rights' => $channelBannedRights]);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$repid.'">'.$repid.'</a> از گروه اخراج شد📛
بدلیل دریافت اخطار 📍','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم به صاحب ربات در گروه اخطار بدهم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم به مدیر ربات در گروه اخطار بدهم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- unwarn-Bot --------
if($msg =="حذف اخطار" || $msg=="/unwarn" || $msg=="unwarn" || $msg=="!unwarn"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$repid = $gmsg['messages'][0]['from_id'];
if(!in_array($repid,$exp)){
if(!in_array($repid,$admins)){
$database_warn["$repid"] = 0;
$outjson = json_encode($database_warn,true);
file_put_contents("warn/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'All Warns For <a href="mention:'.$repid.'">'.$repid.'</a>cleaned❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'تمامی اخطار های کاربر <a href="mention:'.$repid.'">'.$repid.'</a> پاک شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه حذف اخطار کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را حذف اخطار کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
if(strpos($msg,"unwarn ") !== false){
$text = trim(str_replace("unwarn ","",$msg));
$meee = $MadelineProto->get_full_info($text);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$sid = $meeee['id'];
if(!in_array($sid,$exp)){
if(!in_array($sid,$admins)){
$database_warn["$sid"] = 0;
$outjson = json_encode($database_warn,true);
file_put_contents("warn/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'All Warns For <a href="mention:'.$sid.'">'.$first_name1.'</a>cleaned❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'تمامی اخطار های کاربر <a href="mention:'.$sid.'">'.$first_name1.'</a> پاک شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه حذف اخطار کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را حذف اخطار کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(strpos($msg,"حذف اخطار ") !== false){
$text = trim(str_replace("حذف اخطار ","",$msg));
$meee = $MadelineProto->get_full_info($text);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$sid = $meeee['id'];
if(!in_array($sid,$exp)){
if(!in_array($sid,$admins)){
$database_warn["$sid"] = 0;
$outjson = json_encode($database_warn,true);
file_put_contents("warn/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'All Warns For <a href="mention:'.$sid.'">'.$first_name1.'</a>cleaned❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'تمامی اخطار های کاربر <a href="mention:'.$sid.'">'.$first_name1.'</a> پاک شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه حذف اخطار کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را حذف اخطار کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if($msg =="پاکسازی لیست اخطار" || $msg =="حذف لیست اخطار" || $msg =="پاکسازی اخطار" || $msg =="!clear warn" || $msg =="/clear warn" || $msg =="clear warn"){
unlink("warn/$chatID.json");
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Warn List Has Been Cleared☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لیست اخطار با موفقیت پاکسازی شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- SetPic-Bot --------
if($msg == "setpic" || $msg == "/setpic" || $msg == "!setpic" || $msg == "تنظیم عکس گروه"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$photo_id=$gmsg['messages']['0']['media']['photo']['id'];
$photo_hash=$gmsg['messages']['0']['media']['photo']['access_hash'];
if($photo_id !== null){
$inputPhoto = ['_' => 'inputPhoto', 'id' => $photo_id, 'access_hash' => $photo_hash];
$inputChatPhoto = ['_' => 'inputChatPhoto', 'id' => $inputPhoto];
$MadelineProto->channels->editPhoto(['channel' => $chatID, 'photo' => $inputChatPhoto, ]);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'عکس گروه با موفقیت تنظیم شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لطفا روی یک عکس ریپلی کنید!','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- Pin-Bot --------
if($msg =="سنجاق" || $msg=="pin" || $msg=="/pin" || $msg=="!pin"){
$repid = $update['update']['message']['reply_to_msg_id'];
if(isset($update['update']['message']['reply_to_msg_id'])){
$type = $MadelineProto->get_info($chatID);
$typ = $type['type'];
$Updates = $MadelineProto->channels->updatePinnedMessage(['silent' => false, 'channel' => $chatID, 'id' => $repid, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'This Message Hase Been Pinned☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $repid,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'این پیام با موفقیت در گروه سنجاق شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $repid,'parse_mode' => 'html']);	
}
}
}
//-------- UnPin-Bot --------
if($msg =="حذف سنجاق" || $msg=="unpin" || $msg=="/unpin" || $msg=="!unpin"){
$MadelineProto->channels->updatePinnedMessage(['silent' => false, 'channel' => $chatID, 'id' => 0, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'The Pinned Message Hase Been UnPinned☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'پیام سنجاق شده گروه با موفقیت حذف سنجاق شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Clear-Bot --------
if($msg =="del" || $msg =="clear" || $msg =="/del" || $msg =="!del" || $msg =="پاکسازی" || $msg =="حذف"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
if($reply_from_id !== false){
$MadelineProto->channels->deleteUserHistory(['channel' => $chatID, 'user_id' => $reply_from_id, ]);
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
}
//-------- Time-Mute-Bot -------
if(strpos($msg,"سکوت برای ") !== false){
$text = trim(str_replace("سکوت برای ","",$msg));
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
if(!in_array($reply_from_id,$exp)){
if(!in_array($reply_from_id,$admins)){
$meee = $MadelineProto->get_full_info($reply_from_id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$Time_Sec = $text*60*60;
date_default_timezone_set('Asia/Tehran');
$count = time()+ $Time_Sec;
$save = date("g:i:s", $count);
$database_mute["$reply_from_id"]["time"] = $save;
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a>
Muted For '.$text.' hour✅
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a>
به مدت '.$text.' ساعت سکوت شد✅
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>
','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات را در گروه سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
if(strpos($msg,"mute for ") !== false){
$text = trim(str_replace("mute for ","",$msg));
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
if(!in_array($reply_from_id,$exp)){
if(!in_array($reply_from_id,$admins)){
$meee = $MadelineProto->get_full_info($reply_from_id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$Time_Sec = $text*60*60;
date_default_timezone_set('Asia/Tehran');
$count = time()+ $Time_Sec;
$save = date("g:i:s", $count);
$database_mute["$reply_from_id"]["time"] = $save;
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a>
Muted For '.$text.' hour✅
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a>
به مدت '.$text.' ساعت سکوت شد✅
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>
','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات را در گروه سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- Revoke-Link-Bot -------
if($msg =="باطل کردن لینک" || $msg =="لینک جدید" || $msg =="/new link" || $msg =="!new link" || $msg =="new link"){
$ExportedChatInvite = $MadelineProto->channels->exportInvite(['channel' => $chatID, ]);
$newlink = $ExportedChatInvite['link'];
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔹Your New Group Link :
'.$newlink.'
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔹لینک جدید گروه شما :
'.$newlink.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Welcome-Set-Bot -------
if(strpos($msg,"تنظیم خوشامد ") !== false){
$welcome = trim(str_replace("تنظیم خوشامد ","",$msg));
$database["welcome"] = "$welcome";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔸New Welcome Message Has Been Set :
'.$welcome.'
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔸متن خوشامد جدید با موفقیت تنظیم شد :
'.$welcome.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(strpos($msg,"setwelcome ") !== false){
$welcome = trim(str_replace("setwelcome ","",$msg));
$database["welcome"] = "$welcome";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔸New Welcome Message Has Been Set :
'.$welcome.'
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔸متن خوشامد جدید با موفقیت تنظیم شد :
'.$welcome.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Welcome-Del-Bot -------
if($msg =="حذف خوشامد" || $msg =="حذف متن ورود" || $msg =="/welcome disable" || $msg =="!welcome disable" || $msg =="welcome disable" || $msg =="خوشامد خاموش"){
$database["welcome"] = "disable";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Welcome Has Been Disableed☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'متن خوشامد با موفقیت خاموش شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Set-Link-Bot -------
if(strpos($msg,"تنظیم لینک ") !== false){
$link = trim(str_replace("تنظیم لینک ","",$msg));
if(preg_match("/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/", $link)) {
$database["link"] = $link;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'New Link Has Been Seted✅
You can see it with : /link
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لینک گروه ثبت شد✅
شما میتوانید آنرا با دستور [لینک] ببینید
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'برای تنظیم لینک میبایست فقط یک لینک را در پس از دستور جاگذاری کنید❕
دستور ارسالی شما حاوی هیچ لینکی نبود😃','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(strpos($msg,"setlink ") !== false){
$link = trim(str_replace("setlink ","",$msg));
if(preg_match("/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/", $link)) {
$database["link"] = $link;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'New Link Has Been Seted✅
You can see it with : /link
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لینک گروه ثبت شد✅
شما میتوانید آنرا با دستور [لینک] ببینید
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'برای تنظیم لینک میبایست فقط یک لینک را در پس از دستور جاگذاری کنید❕
دستور ارسالی شما حاوی هیچ لینکی نبود😃','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Del-Link-Bot -------
if($msg =="حذف لینک گروه" || $msg =="حذف لینک" || $msg =="/delete link" || $msg =="!delete link" || $msg =="delete link"){
$linkk = $database["link"];
if($linkk !== null){
$database["link"] = '';
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Group Link Has Been Deleted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لینک ثبت شده گروه با موفقیت حذف شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لینک گروه از قبل ثبت نشده بود!','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Ban-Bot -------
if($msg =="بن" || $msg =="مسدود" || $msg =="/ban" || $msg =="!ban" || $msg =="ban" || $msg =="اخراج"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
if(!in_array($reply_from_id,$exp)){
if(!in_array($reply_from_id,$admins)){
if($reply_from_id !== false){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => true, 'send_media' => true, 'send_stickers' => true, 'send_gifs' => true, 'send_games' => true, 'send_inline' => true, 'embed_links' => true, 'until_date' => 0];
$MadelineProto->channels->editBanned(['channel' => $chatID, 'user_id' => $reply_from_id, 'banned_rights' => $channelBannedRights, ]);
$meee = $MadelineProto->get_full_info($reply_from_id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> Hes Been Banned❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> با موفقیت از گروه اخراج شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را از گروه اخراج کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را اخراج کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
if(strpos($msg,"ban ") !== false){
$word = trim(str_replace("ban ","",$msg));
if(isset($update['update']['message']['reply_to_msg_id']) == null){
$meee = $MadelineProto->get_full_info($word);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$sid = $meeee['id'];
if(!in_array($sid,$exp)){
if(!in_array($sid,$admins)){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => true, 'send_media' => true, 'send_stickers' => true, 'send_gifs' => true, 'send_games' => true, 'send_inline' => true, 'embed_links' => true, 'until_date' => 0];
$MadelineProto->channels->editBanned(['channel' => $chatID, 'user_id' => $sid, 'banned_rights' => $channelBannedRights, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$sid.'">'.$first_name1.'</a> Hes Been Banned❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$sid.'">'.$first_name1.'</a> با موفقیت از گروه اخراج شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را از گروه اخراج کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را اخراج کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
if(strpos($msg,"بن ") !== false){
$word = trim(str_replace("بن ","",$msg));
if(isset($update['update']['message']['reply_to_msg_id']) == null){
$meee = $MadelineProto->get_full_info($word);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$sid = $meeee['id'];
if(!in_array($sid,$exp)){
if(!in_array($sid,$admins)){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => true, 'send_media' => true, 'send_stickers' => true, 'send_gifs' => true, 'send_games' => true, 'send_inline' => true, 'embed_links' => true, 'until_date' => 0];
$MadelineProto->channels->editBanned(['channel' => $chatID, 'user_id' => $sid, 'banned_rights' => $channelBannedRights, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$sid.'">'.$first_name1.'</a> Hes Been Banned❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$sid.'">'.$first_name1.'</a> با موفقیت از گروه اخراج شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را از گروه اخراج کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را اخراج کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
if(strpos($msg,"اخراج ") !== false){
$word = trim(str_replace("اخراج ","",$msg));
if(isset($update['update']['message']['reply_to_msg_id']) == null){
$meee = $MadelineProto->get_full_info($word);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$sid = $meeee['id'];
if(!in_array($sid,$exp)){
if(!in_array($sid,$admins)){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => true, 'send_media' => true, 'send_stickers' => true, 'send_gifs' => true, 'send_games' => true, 'send_inline' => true, 'embed_links' => true, 'until_date' => 0];
$MadelineProto->channels->editBanned(['channel' => $chatID, 'user_id' => $sid, 'banned_rights' => $channelBannedRights, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$sid.'">'.$first_name1.'</a> Hes Been Banned❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$sid.'">'.$first_name1.'</a> با موفقیت از گروه اخراج شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را از گروه اخراج کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را اخراج کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- Filter-Bot --------
if(strpos($msg,"فیلتر کردن ") !== false){
$word = trim(str_replace("فیلتر کردن ","",$msg));
$myfile2 = fopen("filter/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$word\n");
fclose($myfile2);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => ''.$word.' Has Been Filterd❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => ''.$word.' با موفقیت فیلتر شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(strpos($msg,"filter ") !== false){
$word = trim(str_replace("filter ","",$msg));
$myfile2 = fopen("filter/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$word\n");
fclose($myfile2);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => ''.$word.' Has Been Filterd❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => ''.$word.' با موفقیت فیلتر شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnFilter-Bot --------
if(strpos($msg,"unfilter ") !== false){
$word = trim(str_replace("unfilter ","",$msg));
$list = file_get_contents("filter/$chatID.txt");
$cleared = str_replace("$word","",$list);
 file_put_contents("filter/$chatID.txt","$cleared");
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => ''.$word.' Has Been UnFiltered❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => ''.$word.' با موفقیت حذف فیلتر شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(strpos($msg,"حذف فیلتر ") !== false){
$word = trim(str_replace("حذف فیلتر ","",$msg));
$list = file_get_contents("filter/$chatID.txt");
$cleared = str_replace("$word","",$list);
 file_put_contents("filter/$chatID.txt","$cleared");
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => ''.$word.' Has Been UnFiltered❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => ''.$word.' با موفقیت حذف فیلتر شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Clear-Filter-Bot --------
if($msg =="پاکسازی لیست فیلتر" || $msg =="حذف لیست فیلتر" || $msg =="پاکسازی فیلتر" || $msg =="!clear filter" || $msg =="/clear filter" || $msg =="clear filter"){
unlink("filter/$chatID.txt");
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Filter List Has Been Cleared☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لیست فیلتر با موفقیت پاکسازی شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Filter-List-Bot --------
if($msg =="لیست فیلتر" || $msg =="کلمات فیلتر" || $msg =="!filter list" || $msg =="/filter list" || $msg =="filter list"){
if(file_exists("filter/$chatID.txt")){
$list = file_get_contents("filter/$chatID.txt");
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔹Your Group Filter List :
'.$list.'
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔹لیست کلمات فیلتر در گروه شما :
'.$list.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "Filter List Is Empty❗️",'reply_to_msg_id' => $msg_id,]);
}
}
//-------- Promote-Bot --------
if($msg =="ترفیع" || $msg =="ارتقا" || $msg =="promote" || $msg =="!promote" || $msg =="/promote"){
if($userID == $owner or in_array($userID,$admins)){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
if($reply_from_id !== false){
if(!in_array($reply_from_id,$exp)){
$myfile2 = fopen("admins/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "\n$reply_from_id");
fclose($myfile2);
$meee = $MadelineProto->get_full_info($reply_from_id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> Has Been Promoted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> با موفقیت ادمین ربات شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'این شخص از قبل مدیر بود😊','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
}
}
if(strpos($msg,"ترفیع ") !== false){
$id = trim(str_replace("ترفیع ","",$msg));
if($userID == $owner or in_array($userID,$admins)){
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$meee = $MadelineProto->get_full_info($id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$from_id = $meeee['id'];
if(!in_array($from_id,$exp)){
$myfile2 = fopen("admins/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "\n$from_id");
fclose($myfile2);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$from_id.'">'.$first_name1.'</a> Has Been Promoted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$from_id.'">'.$first_name1.'</a> با موفقیت ادمین ربات شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'این شخص از قبل مدیر بود😊','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
}
if(strpos($msg,"promote ") !== false){
$id = trim(str_replace("promote ","",$msg));
if($userID == $owner or in_array($userID,$admins)){
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$meee = $MadelineProto->get_full_info($id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$from_id = $meeee['id'];
if(!in_array($from_id,$exp)){
$myfile2 = fopen("admins/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "\n$from_id");
fclose($myfile2);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$from_id.'">'.$first_name1.'</a> Has Been Promoted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$from_id.'">'.$first_name1.'</a> با موفقیت ادمین ربات شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'این شخص از قبل مدیر بود😊','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
}
//-------- Demote-Bot --------
if($msg =="تنزل" || $msg =="demote" || $msg =="!demote" || $msg =="/demote"){
if($userID == $owner or in_array($userID,$admins)){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
if($reply_from_id !== false){
if(in_array($reply_from_id,$exp)){
$source = file_get_contents("admins/$chatID.txt");
$source1 = str_replace("$reply_from_id","",$source);
$source = file_put_contents("admins/$chatID.txt",$source1);
$meee = $MadelineProto->get_full_info($reply_from_id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> Has Been Demoted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'مقام <a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> با موفقیت از ادمینی ربات خارج شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'این شخص مدیر ربات است😊','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
}
}
if(strpos($msg,"demote ") !== false){
$id = trim(str_replace("demote ","",$msg));
if($userID == $owner or in_array($userID,$admins)){
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$meee = $MadelineProto->get_full_info($id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$from_id = $meeee['id'];
if(in_array($from_id,$exp)){
$source = file_get_contents("admins/$chatID.txt");
$source1 = str_replace("$from_id","",$source);
$source = file_put_contents("admins/$chatID.txt",$source1);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$from_id.'">'.$first_name1.'</a> Has Been Demoted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'مقام <a href="mention:'.$from_id.'">'.$first_name1.'</a> با موفقیت از ادمینی ربات خارج شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'این شخص مدیر ربات است😊','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
}
if(strpos($msg,"تنزل ") !== false){
$id = trim(str_replace("تنزل ","",$msg));
if($userID == $owner or in_array($userID,$admins)){
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$meee = $MadelineProto->get_full_info($id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$from_id = $meeee['id'];
if(in_array($from_id,$exp)){
$source = file_get_contents("admins/$chatID.txt");
$source1 = str_replace("$from_id","",$source);
$source = file_put_contents("admins/$chatID.txt",$source1);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$from_id.'">'.$first_name1.'</a> Has Been Demoted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'مقام <a href="mention:'.$from_id.'">'.$first_name1.'</a> با موفقیت از ادمینی ربات خارج شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'این شخص مدیر ربات است😊','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
}
//-------- History-Bot --------
if($msg == "history on" or $msg == "/history on" or $msg == "!history on" or $msg == "تاریخچه فعال" or $msg == "تاریخچه روشن" or $msg == "فعال کردن تاریخچه" or $msg == "روشن کردن تاریخچه"){
$Updates = $MadelineProto->channels->togglePreHistoryHidden(['channel' => $chatID, 'enabled' => false, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Show previous group messages for those who are new to the group Enabled✅
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'نمایش پیام های قبلی گروه برای کسانی که تازه به گروه ملحق میشوند فعال شد✅
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if($msg == "history off" or $msg == "/history off" or $msg == "!history off" or $msg == "تاریخچه غیرفعال" or $msg == "تاریخچه خاموش" or $msg == "غیرفعال کردن تاریخچه" or $msg == "خاموش کردن تاریخچه"){
$Updates = $MadelineProto->channels->togglePreHistoryHidden(['channel' => $chatID, 'enabled' => true, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Show previous group messages for those who are new to the group Disabled📛
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'نمایش پیام های قبلی گروه برای کسانی که تازه به گروه ملحق میشوند غیرفعال شد📛
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Invite-Bot --------
if($msg == "add on" or $msg == "/add on" or $msg == "!add on" or $msg == "ادد باز" or $msg == "ادد فعال" or $msg == "فعال کردن ادد" or $msg == "بازکردن ادد" or $msg == "باز کردن ادد"){
$MadelineProto->channels->toggleInvites(['channel' => $chatID, 'enabled' => true, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Invite someone who has just joined the group is invited Enabled✅
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'دعوت کردن مخاطبین کسی که تازه به گروه ملحق شده فعال شد✅
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if($msg == "add off" or $msg == "/add off" or $msg == "!add off" or $msg == "ادد بسته" or $msg == "ادد غیرفعال" or $msg == "غیرفعال کردن ادد" or $msg == "بستن ادد"){
$MadelineProto->channels->toggleInvites(['channel' => $chatID, 'enabled' => false, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Invite someone who has just joined the group is invited Disabled📛
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'دعوت کردن مخاطبین کسی که تازه به گروه ملحق شده غیرفعال شد📛
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Admins-Bot --------
if($msg =="لیست ادمین ها" || $msg =="ادمین ها" || $msg =="admins" || $msg =="/admins" || $msg =="!admins"){
$admins = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' =>['_' => 'channelParticipantsAdmins'], 'offset' => 0, 'limit' => 25, 'hash' => 0, ]);
$m = $MadelineProto->get_full_info($owner);
$me1 = $m['User'];
$nme_name = $me1['first_name'];
$source = '';
foreach($admins['participants'] as $admin){
$adminn = $admin['user_id'];
$mee = $MadelineProto->get_full_info($adminn);
$me = $mee['User'];
$me_name = $me['first_name'];
$mention = '<a href="mention:'.$adminn.'">'.$me_name.'</a>';
$source .= ''.$mention."\n";
}
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '▪️Group Admins List :
'.$source.'
——————
➰Owner : <a href="mention:'.$owner.'">'.$nme_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '▪️لیست ادمین های گروه :
'.$source.'
——————
➰صاحب گروه : <a href="mention:'.$owner.'">'.$nme_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Mute-Bot --------
if($msg =="سکوت" || $msg =="بیصدا" || $msg =="خفه" || $msg =="!mute" || $msg =="/mute" || $msg =="mute" || $msg =="سایلنت" || $msg =="silent" || $msg =="/silent" || $msg =="!silent"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
if($reply_from_id !== false){
if(!in_array($reply_from_id,$exp)){
if(!in_array($reply_from_id,$admins)){
$database_mute["$reply_from_id"]["time"] = "0";
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
$meee = $MadelineProto->get_full_info($reply_from_id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> Has Been Muted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> با موفقیت بیصدا شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
}
if(strpos($msg,"mute ") !== false){
$word = trim(str_replace("mute ","",$msg));
$meee = $MadelineProto->get_full_info($word);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$id = $meeee['id'];
if(!in_array($id,$exp)){
if(!in_array($id,$admins)){
$database_mute["$id"]["time"] = "0";
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$id.'">'.$first_name1.'</a> Has Been Muted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$id.'">'.$first_name1.'</a> با موفقیت بیصدا شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(strpos($msg,"بیصدا ") !== false){
$word = trim(str_replace("بیصدا ","",$msg));
$meee = $MadelineProto->get_full_info($word);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$id = $meeee['id'];
if(!in_array($id,$exp)){
if(!in_array($id,$admins)){
$database_mute["$id"]["time"] = "0";
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$id.'">'.$first_name1.'</a> Has Been Muted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$id.'">'.$first_name1.'</a> با موفقیت بیصدا شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnMute-Bot --------
if($msg =="حذف سکوت" || $msg =="باصدا" || $msg =="لغو سکوت" || $msg =="!unmute" || $msg =="/unmute" || $msg =="unmute" || $msg =="unsilent" || $msg =="/unsilent" || $msg =="!unsilent"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
if($reply_from_id !== false){
if(!in_array($reply_from_id,$exp)){
if(!in_array($reply_from_id,$admins)){
$database_mute["$reply_from_id"]["time"] = "";
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
$meee = $MadelineProto->get_full_info($reply_from_id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> Has Been UnMuted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> با موفقیت باصدا شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه حذف سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را حذف سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
}
if(strpos($msg,"باصدا ") !== false){
$word = trim(str_replace("باصدا ","",$msg));
$meee = $MadelineProto->get_full_info($word);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$id = $meeee['id'];
if(!in_array($id,$exp)){
if(!in_array($id,$admins)){
$database_mute["$id"]["time"] = "";
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$id.'">'.$first_name1.'</a> Has Been UnMuted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$id.'">'.$first_name1.'</a> با موفقیت باصدا شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه حذف سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را حذف سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(strpos($msg,"unmute ") !== false){
$word = trim(str_replace("unmute ","",$msg));
$meee = $MadelineProto->get_full_info($word);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$id = $meeee['id'];
if(!in_array($id,$exp)){
if(!in_array($id,$admins)){
$database_mute["$id"]["time"] = "";
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$id.'">'.$first_name1.'</a> Has Been UnMuted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$id.'">'.$first_name1.'</a> با موفقیت باصدا شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم صاحب ربات را در گروه حذف سکوت کنم??','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'من نمیتوانم ادمین ربات در گروه را حذف سکوت کنم💀','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Clear-Mute-Bot --------
if($msg =="پاکسازی لیست سکوت" || $msg =="حذف لیست سکوت" || $msg =="پاکسازی سکوت" || $msg =="!clear mute" || $msg =="/clear mute" || $msg =="clear mute"){
unlink("mute/$chatID.json");
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Mute List Has Been Cleared☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لیست سکوت با موفقیت پاکسازی شد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Mute-List-Bot --------
/*if($msg =="لیست سکوت" || $msg =="افراد بیصدا" || $msg =="لیست بیصدا" || $msg =="!mute list" || $msg =="/mute list" || $msg =="mute list"){
if(file_exists("mute/$chatID.txt")){
 $us = file_get_contents("mute/$chatID.txt");
 $exusr = explode("\n",$us);
 $c = count($exusr)-1;
$msg = "";
for($z = $c-10;$z <= $c;$z++){
if($exusr[$z] != null){
$mee = $MadelineProto->get_full_info($exusr[$z]);
$me = $mee['User'];
$me_name = $me['first_name'];
$mention = '<a href="mention:'.$exusr[$z].'">'.$me_name.'</a>';
$msg = "$msg$mention | UserId : $exusr[$z]\n";
}
}
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔹Your Group Muted Users :
'.$msg.'','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '🔹لیست افراد بیصدا در گروه شما :
'.$msg.'','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "Mute List Is Empty❗️",'reply_to_msg_id' => $msg_id,]);
}
}*/
//-------- Name-Bot --------
if(strpos($msg,"تنظیم نام گروه ") !== false){
$title = trim(str_replace("تنظیم نام گروه ","",$msg));
$MadelineProto->channels->editTitle(['channel' => $chatID, 'title' => $title, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Group Title Has Been changed☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'نام گروه با موفقیت تغییر کرد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(preg_match("/^[\/\#\!]?(setgroupname) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(setgroupname) (.*)$/i", $msg, $text);
$title = $text[2];
$MadelineProto->channels->editTitle(['channel' => $chatID, 'title' => $title, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Group Title Has Been changed☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'نام گروه با موفقیت تغییر کرد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Description-Bot --------
if(strpos($msg,"تنظیم توضیحات گروه ") !== false){
$about = trim(str_replace("تنظیم توضیحات گروه ","",$msg));
$MadelineProto->channels->editAbout(['channel' => $chatID, 'about' => $about, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Group Description Has Been changed☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'توضیحات گروه با موفقیت تغییر کرد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(preg_match("/^[\/\#\!]?(setgroupdes) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(setgroupdes) (.*)$/i", $msg, $text);
$about = $text[2];
$MadelineProto->channels->editAbout(['channel' => $chatID, 'about' => $about, ]);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Group Description Has Been changed☑️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'توضیحات گروه با موفقیت تغییر کرد☑️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lang-Bot --------
if(strpos($msg,"زبان ") !== false){
$link = trim(str_replace("زبان ","",$msg));
$txxxt1 = str_replace("فارسی","fa",$link);
$txxxt2 = str_replace("انگلیسی","en",$txxxt1);
$database["lang"] = $txxxt2;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($txxxt2 == "fa"){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => 'زبان گروه به فارسی تغییر کرد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html' ]);
}
if($txxxt2 == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => 'Group Language Has Been changed To English✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html' ]);
}
}
if(preg_match("/^[\/\#\!]?(setlang) (en|fa)$/i", $msg)){
preg_match("/^[\/\#\!]?(setlang) (en|fa)$/i", $msg, $text);
$database["lang"] = $text[2];
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($text[2] == "fa"){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => 'زبان گروه به فارسی تغییر کرد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html' ]);
}
if($text[2] == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => 'Group Language Has Been changed To English✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html' ]);
}
}
//-------- Lock-Mention --------
if($msg =="قفل منشن" || $msg=="قفل کردن منشن" || $msg=="/lock mention" || $msg=="lock mention" || $msg=="!lock mention"){
if($lock_mention == "off"){
$database['lock']['mention'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Mention Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'منشن با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال پیام حاوی منشن از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Mention --------
if($msg =="بازکردن منشن" || $msg=="باز کردن منشن" || $msg=="/unlock mention" || $msg=="unlock mention" || $msg=="!unlock mention"){
if($lock_mention == "on"){
$database['lock']['mention'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Mention Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'منشن با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال پیام حاوی منشن از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Strict-bot --------
if($msg =="سخت روشن" || $msg=="روشن کردن حالت سخت" || $msg=="حالت سخت روشن" || $msg=="فعال کردن حالت سخت" || $msg=="/strict enable" || $msg=="strict enable" || $msg=="!strict enable"){
if($strict_mode == "disable"){
$database['strict_mode'] = "enable";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Strict Has Been Enable in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'حالیت سختگیرانه در گروه فعال شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'حالت سخت از قبل روشن بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Strict-bot --------
if($msg =="سخت خاموش" || $msg=="خاموش کردن حالت سخت" || $msg=="حالت سخت خاموش" || $msg=="غیر فعال کردن حالت سخت" || $msg=="/strict disable" || $msg=="strict disable" || $msg=="!strict disable"){
if($strict_mode == "enable"){
$database['strict_mode'] = "disable";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Strict Has Been Disable in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'حالیت سختگیرانه در گروه غیرفعال شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'حالت سخت از قبل خاموش بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Tabchi --------
if($msg =="قفل تبچی" || $msg=="قفل کردن تبچی" || $msg=="/lock tabchi" || $msg=="lock tabchi" || $msg=="!lock tabchi"){
if($lock_tabchi == "off"){
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$database['lock']['tabchi'] = "on";
$database['lock']['tg'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Tabchi Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ورود تبچی با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ورود تبچی از قبل ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Tabchi --------
if($msg =="بازکردن تبچی" || $msg=="باز کردن تبچی" || $msg=="/unlock tabchi" || $msg=="unlock tabchi" || $msg=="!unlock tabchi"){
if($lock_tabchi == "on"){
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$database['lock']['tabchi'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Tabchi Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ورود تبچی با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ورود تبچی از قبل آزاد بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-All --------
if($msg =="قفل همه" || $msg=="قفل گروه" || $msg=="/lock all" || $msg=="lock all" || $msg=="!lock all"){
if($lock_all == "off"){
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$database['lock']['all'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Group Has Been Muted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'گروه با موفقیت بیصدا شد❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'گروه از قبل بسته بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-All --------
if($msg =="بازکردن همه" || $msg=="باز کردن همه" || $msg=="بازکردن گروه" || $msg=="باز کردن گروه" || $msg=="/unlock all" || $msg=="unlock all" || $msg=="!unlock all"){
if($lock_all == "on"){
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$database['lock']['all'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Group Has Been UnMuted❕
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'قفل گروه باز شد و کاربران قادر به چت هستند❕
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'گروه از قبل باز بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-bot --------
if($msg =="قفل ربات" || $msg=="قفل کردن ربات" || $msg=="/lock bot" || $msg=="lock bot" || $msg=="!lock bot"){
if($lock_bot == "off"){
$database['lock']['bot'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Bot Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ربات با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ورود و ادد کردن ربات به گروه از قبل ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-bot --------
if($msg =="بازکردن ربات" || $msg=="باز کردن ربات" || $msg=="/unlock bot" || $msg=="unlock bot" || $msg=="!unlock bot"){
if($lock_bot == "on"){
$database['lock']['bot'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Bot Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ربات با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ورود و ادد کردن ربات به گروه از قبل آزاد بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-tg --------
if($msg =="قفل خدمات تلگرام" || $msg=="قفل سرویس" || $msg=="/lock tg" || $msg=="lock tg" || $msg=="!lock tg"){
if($lock_tg == "off"){
$database['lock']['tg'] = "on";
$database['lock']['tabchi'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Tg-Services Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'خدمات تلگرام با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'پیام های ورود و خروج کاربر از قبل قفل بود و در گروه نمایش داده نمیشد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-tg --------
if($msg =="بازکردن خدمات تلگرام" || $msg=="بازکردن سرویس" || $msg=="/unlock tg" || $msg=="unlock tg" || $msg=="!unlock tg"){
if($lock_tg == "on"){
$database['lock']['tg'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Tg-Services Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'خدمات تلگرام با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'پیام های ورود و خروج کاربر از قبل باز بود و در گروه نمایش داده میشد✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Contact --------
if($msg =="قفل مخاطب" || $msg=="قفل کردن مخاطب" || $msg=="/lock contact" || $msg=="lock contact" || $msg=="!lock contact"){
if($lock_contact == "off"){
$database['lock']['contact'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Contact Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'مخاطب با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال مخاطب از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Contact --------
if($msg =="بازکردن مخاطب" || $msg=="باز کردن مخاطب" || $msg=="/unlock contact" || $msg=="unlock contact" || $msg=="!unlock contact"){
if($lock_contact == "on"){
$database['lock']['contact'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Contact Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'مخاطب با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال مخاطب از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Via --------
if($msg =="قفل فراخوانی" || $msg=="قفل کردن فراخوانی" || $msg=="/lock via" || $msg=="lock via" || $msg=="!lock via"){
if($lock_via == "off"){
$database['lock']['via'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Via Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'فراخوانی با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال پست با ربات اینلاین از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Via --------
if($msg =="بازکردن فراخوانی" || $msg=="باز کردن فراخوانی" || $msg=="/unlock via" || $msg=="unlock via" || $msg=="!unlock via"){
if($lock_via == "on"){
$database['lock']['via'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Via Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'فراخوانی با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال پست با ربات اینلاین از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Inline --------
if($msg =="قفل دکمه شیشه ای" || $msg=="قفل کردن دکمه شیشه ای" || $msg=="/lock inline" || $msg=="lock inline" || $msg=="!lock inline"){
if($lock_inline == "off"){
$database['lock']['inline'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Inline Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'دکمه شیشه ای با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن با دکمه شیشه ای از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Inline --------
if($msg =="بازکردن دکمه شیشه ای" || $msg=="باز کردن دکمه شیشه ای" || $msg=="/unlock inline" || $msg=="unlock inline" || $msg=="!unlock inline"){
if($lock_inline == "on"){
$database['lock']['inline'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Inline Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'دکمه شیشه ای با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن با دکمه شیشه ای از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-music --------
if($msg =="قفل موزیک" || $msg=="قفل کردن موزیک" || $msg=="/lock music" || $msg=="lock music" || $msg=="!lock music"){
if($lock_music == "off"){
$database['lock']['music'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Music Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'موزیک با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال موزیک از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-music --------
if($msg =="بازکردن موزیک" || $msg=="باز کردن موزیک" || $msg=="/unlock music" || $msg=="unlock music" || $msg=="!unlock music"){
if($lock_music == "on"){
$database['lock']['music'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Music Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'موزیک با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال موزیک از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-forward --------
if($msg =="قفل فروارد" || $msg=="قفل کردن فروارد" || $msg=="/lock forward" || $msg=="lock forward" || $msg=="!lock forward"){
if($lock_forward == "off"){
$database['lock']['forward'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Forward Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'فروارد با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال پیام فرواردی از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-forward --------
if($msg =="بازکردن فروارد" || $msg=="باز کردن فروارد" || $msg=="/unlock forward" || $msg=="unlock forward" || $msg=="!unlock forward"){
if($lock_forward == "on"){
$database['lock']['forward'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Forward Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'فروارد با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال پیام فرواردی از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Flood --------
if($msg =="قفل اسپم" || $msg=="قفل کردن اسپم" || $msg=="/lock flood" || $msg=="lock flood" || $msg=="!lock flood"){
if($lock_flood == "off"){
$database['lock']['flood'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Flood Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'اسپم با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال پیام مکرر از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Flood --------
if($msg =="بازکردن اسپم" || $msg=="باز کردن اسپم" || $msg=="/lock flood" || $msg=="unlock flood" || $msg=="!unlock flood"){
if($lock_flood == "on"){
$database['lock']['flood'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Flood Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'اسپم با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال پیام مکرر از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-location --------
if($msg =="قفل موقعیت مکانی" || $msg=="قفل کردن موقعیت مکانی" || $msg=="/lock location" || $msg=="lock location" || $msg=="!lock location"){
if($lock_location == "off"){
$database['lock']['location'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Location Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'استیکر با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال موقعیت مکانی از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-location --------
if($msg =="بازکردن موقعیت مکانی" || $msg=="باز کردن موقعیت مکانی" || $msg=="/unlock location" || $msg=="unlock location" || $msg=="!unlock location"){
if($lock_location == "on"){
$database['lock']['location'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Location Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'استیکر با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال موقعیت مکانی از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-sticker --------
if($msg =="قفل استیکر" || $msg=="قفل کردن استیکر" || $msg=="/lock sticker" || $msg=="lock sticker" || $msg=="!lock sticker"){
if($lock_sticker == "off"){
$database['lock']['sticker'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Sticker Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'استیکر با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال استیکر از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-sticker --------
if($msg =="بازکردن استیکر" || $msg=="باز کردن استیکر" || $msg=="/unlock sticker" || $msg=="unlock sticker" || $msg=="!unlock sticker"){
if($lock_sticker == "on"){
$database['lock']['sticker'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Sticker Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'استیکر با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال استیکر از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-voice --------
if($msg =="قفل ویس" || $msg=="قفل کردن ویس" || $msg=="/lock voice" || $msg=="lock voice" || $msg=="!lock voice"){
if($lock_voice == "off"){
$database['lock']['voice'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Voice Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ویس با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال ویس از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-voice --------
if($msg =="بازکردن ویس" || $msg=="باز کردن ویس" || $msg=="/unlock voice" || $msg=="unlock voice" || $msg=="!unlock voice"){
if($lock_voice == "on"){
$database['lock']['voice'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Voice Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ویس با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال ویس از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Link --------
if($msg =="قفل لینک" || $msg=="قفل کردن لینک" || $msg=="/lock link" || $msg=="lock link" || $msg=="!lock link"){
if($lock_link == "off"){
$database['lock']['link'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Link Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لینک با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن حاوی لینک از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Link --------
if($msg =="بازکردن لینک" || $msg=="باز کردن لینک" || $msg=="/unlock link" || $msg=="unlock link" || $msg=="!unlock link"){
if($lock_link == "on"){
$database['lock']['link'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Link Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لینک با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن حاوی لینک از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Text --------
if($msg =="قفل متن" || $msg=="قفل کردن متن" || $msg=="/lock text" || $msg=="lock text" || $msg=="!lock text"){
if($lock_text == "off"){
$database['lock']['text'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Text Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Text --------
if($msg =="بازکردن متن" || $msg=="باز کردن متن" || $msg=="/unlock text" || $msg=="unlock text" || $msg=="!unlock text"){
if($lock_text == "on"){
$database['lock']['text'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Text Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-English --------
if($msg =="قفل انگلیسی" || $msg=="قفل کردن انگلیسی" || $msg=="/lock english" || $msg=="lock english" || $msg=="!lock english"){
if($lock_english == "off"){
$database['lock']['english'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'English Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن انگلیسی با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن حاوی کلمات انگلیسی از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-English --------
if($msg =="بازکردن انگلیسی" || $msg=="باز کردن انگلیسی" || $msg=="/unlock english" || $msg=="unlock english" || $msg=="!unlock english"){
if($lock_english == "on"){
$database['lock']['english'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'English Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن انگلیسی با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن حاوی کلمات انگلیسی از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Username --------
if($msg =="قفل یوزرنیم" || $msg=="قفل آیدی" || $msg=="/lock username" || $msg=="lock username" || $msg=="!lock username"){
if($lock_username == "off"){
$database['lock']['username'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Username Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'یوزرنیم با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن حاوی یوزرنیم از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Username --------
if($msg =="بازکردن یوزرنیم" || $msg=="باز کردن یوزرنیم" || $msg=="باز کردن آیدی" || $msg=="/unlock username" || $msg=="unlock username" || $msg=="!unlock username"){
if($lock_username == "on"){
$database['lock']['username'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Username Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'یوزرنیم با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال متن حاوی یوزرنیم از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Document --------
if($msg =="قفل رسانه" || $msg=="قفل کردن رسانه" || $msg=="/lock document" || $msg=="lock document" || $msg=="!lock document"){
if($lock_document == "off"){
$database['lock']['document'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Document Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'رسانه با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال رسانه از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Document --------
if($msg =="بازکردن رسانه" || $msg=="باز کردن رسانه" || $msg=="/unlock document" || $msg=="unlock document" || $msg=="!unlock document"){
if($lock_document == "on"){
$database['lock']['document'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Document Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'رسانه با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال رسانه از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Lock-Photo --------
if($msg =="قفل عکس" || $msg=="قفل تصویر" || $msg=="/lock photo" || $msg=="lock photo" || $msg=="!lock photo"){
if($lock_photo == "off"){
$database['lock']['photo'] = "on";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Photo Has Been Locked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'عکس با موفقیت در این گروه قفل شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال عکس از قبل برای کاربران گروه ممنوع بود📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- UnLock-Photo --------
if($msg =="بازکردن عکس" || $msg=="باز کردن عکس" || $msg=="باز کردن تصویر" || $msg=="/unlock photo" || $msg=="unlock photo" || $msg=="!unlock photo"){
if($lock_photo == "on"){
$database['lock']['photo'] = "off";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Photo Has Been UnLocked in This Group✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'عکس با موفقیت در این گروه باز شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'ارسال عکس از قبل برای کاربران گروه محیا بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}

//ربات محافظ گروه cli


}else{
}
}else{
}
}else{
}
}else{
}
